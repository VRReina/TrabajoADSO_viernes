function sumar() {
    var n1, n2, 
    n1= Number(prompt("Ingresar numero 1 a sumar"));
    n2 = Number(prompt("Ingresar numero 2 a sumar"));
    suma =(n1+n2)
   alert('la suma es: '+ suma);
}

function rest() {
    var n1, n2, 
    n1= Number(prompt("Ingresar numero 1 a restar"));
    n2 = Number(prompt("Ingresar numero 2 a restar"));
    resta =(n1-n2)
   alert('la resta es: '+ resta);
}

function multi() {
    var n1, n2, 
    n1= Number(prompt("Ingresar numero 1 a multiplicar"));
    n2 = Number(prompt("Ingresar numero 2 a multiplicar"));
    multiplicar =(n1*n2)
   alert('la multiplicacion es: '+ multiplicar);
}

function divi() {
    var n1, n2, 
    n1= Number(prompt("Ingresar numero 1 a dividir"));
    n2 = Number(prompt("Ingresar numero 2 a dividir"));
    division =(n1/n2)
   alert('la division es: '+ division);
}
function promedio() {
    var n1, n2,n3 
    n1= Number(prompt("Ingresar numero 1 "));
    n2 = Number(prompt("Ingresar numero 2 "));
    n3 = Number(prompt("Ingresar numero 3 "));
    prome =(n1+n2+n3)/3
   alert('El promedio es: '+ prome);
}

function porcentaje() {
    var n1, n2
    n1= Number(prompt("Ingresar numero"));
    n2 = Number(prompt("Ingresar el porcentaje "));
    por = (n1*n2)/100
   alert('El promedio es: '+ por + '%');
}
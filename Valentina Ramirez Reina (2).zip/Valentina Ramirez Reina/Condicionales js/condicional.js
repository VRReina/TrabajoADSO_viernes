//crea un programa por pantalla que si erres mayor de 18 años te diga si ingresas de lo contario no 

var edad;

edad = prompt("Introduce tu edad");

if (edad >= 18){
	document.write("Puedes entrar, eres mayor de edad.");
} else {
	document.write("No puedes entrar, eres menor de edad.");
}


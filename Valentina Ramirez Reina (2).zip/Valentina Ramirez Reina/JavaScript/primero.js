/*console.log("Empezando a programar con JavaScript")
document.write("Primero pasos en JavaScript")
alert("Estoy programando en JavaScript")*/

/*
var numero= 4;
console.log(numero);

var n1= 9;
var n2=19;
suma=n1+n2;
console.log(suma);

var n1= 20;
var n2=10;
resta=n1-n2;
alert(resta);

var n1= 20;
var n2=2;
multiplicacion=n1*n2;
alert(multiplicacion);

var n1= 6;
var n2=6;
division=n1/n2;
alert(division);
*/
 
var l1= Number (prompt("Ingrese Lado 1"))
var l2= Number (prompt("Ingrese Lado 2"))
area=l1*l2;
document.write("El area del cuadrado es :" + area);


